Instruction: 
http://soko1.livejournal.com/633448.html

Contacts: 
Sakalou Aliaksei <nullbsd@gmail.com>
