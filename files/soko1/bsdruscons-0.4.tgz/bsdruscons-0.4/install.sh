#!/bin/sh

# Copyright (c) 2007 Sokolov Alexey <nullbsd@gmail.com>
# All rights reserved.
#
# Redistribution and use in source and binary forms, with or without
# modification, are permitted provided that the following conditions
# are met:
# 1. Redistributions of source code must retain the above copyright
#    notice, this list of conditions and the following disclaimer.
# 2. Redistributions in binary form must reproduce the above copyright
#    notice, this list of conditions and the following disclaimer in the
#    documentation and/or other materials provided with the distribution.
#
# THIS SOFTWARE IS PROVIDED BY THE AUTHOR AND CONTRIBUTORS ``AS IS'' AND
# ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
# IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
# ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR OR CONTRIBUTORS BE LIABLE
# FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
# DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
# OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
# HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
# LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
# OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
# SUCH DAMAGE.

PATH="$PATH:/bin:/usr/bin"
WORLDSRC="/usr/src"

if [ `whoami` != "root" ]; then
    echo "I need root permission!"
    exit
fi

OS="`uname -s`"

case $OS in
    FreeBSD )
	;;
    NetBSD )
	;;
    * )
	printf "I need OS NetBSD or FreeBSD!"
	exit
	;;
esac

# NetBSD
if [ "$OS" = "NetBSD" ]; then
    
    if [ ! -f $WORLDSRC/sys/dev/wscons/wskbd.c ]; then
	echo "I need kernel sources NetBSD!"
	exit
    fi

# /usr/share/wscons/fonts/koi8.816
    cp fonts/koi8.816 /usr/share/wscons/fonts/koi8.816
    
# /etc/wscons.conf
    cp /etc/wscons.conf /etc/wscons.conf.orig
    #echo "encoding=ru" >> /etc/wscons.conf
    echo "font koi8 - - iso /usr/share/wscons/fonts/koi8.816
mapfile /usr/share/wscons/keymaps/pckbd.ru.koi8-r" >> /etc/wscons.conf
    
# sys/dev/wscons/wskbd.c
    cp $WORLDSRC/sys/dev/wscons/wskbd.c $WORLDSRC/sys/dev/wscons/wskbd.c.orig
    sed  s/"0, MOD_MODESHIFT"/"1, MOD_MODESHIFT"/ $WORLDSRC/sys/dev/wscons/wskbd.c > /tmp/.wskbd.c
    mv /tmp/.wskbd.c $WORLDSRC/sys/dev/wscons/wskbd.c
    
# /etc/rc.local
    cp /etc/rc.local /etc/rc.local.orig
    echo "/sbin/wsconsctl -f /dev/ttyE0 -dw font=koi8 > /dev/null" >> /etc/rc.local
    echo "/sbin/wsconsctl -f /dev/ttyE1 -dw font=koi8 > /dev/null" >> /etc/rc.local
    echo "/sbin/wsconsctl -f /dev/ttyE2 -dw font=koi8 > /dev/null" >> /etc/rc.local
    echo "/sbin/wsconsctl -f /dev/ttyE3 -dw font=koi8 > /dev/null" >> /etc/rc.local
    
# /etc/profile
    cp /etc/profile /etc/profile.orig
    echo "LANG=ru_RU.KOI8-R; export LANG
MM_CHARSET=KOI8-R; export MM_CHARSET" >> /etc/profile

# /etc/csh.cshrc
    cp /etc/csh.cshrc /etc/csh.cshrc.orig
    echo "setenv LC_CTYPE ru_RU.KOI8-R
setenv LANG ru_RU.KOI8-R
setenv MM_CHARSET KOI8-R" >> /etc/csh.cshrc
    
# ~/.inputrc
    if [ -f ~/.inputrc ]; then
	cp ~/.inputrc ~/.inputrc.orig
    fi
    echo "set convert-meta off 
    set input-meta on 
    set output-meta on" >> ~/.inputrc
    
    echo "Russian NetBSD among You! :)"
    echo "---"
    echo "Please, recompile your kernel and reboot computer..."
fi

# FreeBSD
if [ "$OS" = "FreeBSD" ]; then
# /usr/share/syscons/fonts/866-terminus-8x16.fnt
    cp fonts/866-terminus-8x16.fnt /usr/share/syscons/fonts

# /etc/rc.conf
    cp /etc/rc.conf /etc/rc.conf.orig
    echo '
font8x16="866-terminus-8x16"
keymap="ru.koi8-r.win"
scrnmap="koi8-r2cp866"' >> /etc/rc.conf

# /etc/ttys
    cp /etc/ttys /etc/ttys.orig
    TTY_C=`cat /etc/ttys | grep ttyv0 | awk '{print $4}'`
    sed -i "" s/"[[:<:]]$TTY_C[[:>:]]"/"cons25r"/g /etc/ttys

# /etc/profile
    cp /etc/profile /etc/profile.orig
    echo "LANG=ru_RU.KOI8-R; export LANG
MM_CHARSET=KOI8-R; export MM_CHARSET" >> /etc/profile

# /etc/csh.cshrc
    cp /etc/csh.cshrc /etc/csh.cshrc.orig
    echo "setenv LC_CTYPE ru_RU.KOI8-R
setenv LANG ru_RU.KOI8-R
setenv MM_CHARSET KOI8-R" >> /etc/csh.cshrc

    echo "Russian FreeBSD among You! :)"
    echo "Please, reboot computer or restart script /etc/rc.d/syscons"
fi
