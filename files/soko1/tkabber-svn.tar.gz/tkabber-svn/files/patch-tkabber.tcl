--- tkabber.tcl.orig	2008-07-29 11:31:05.000000000 +0400
+++ tkabber.tcl	2008-07-29 11:31:49.000000000 +0400
@@ -100,7 +100,7 @@
     return $snapshot
 }
 
-set tkabber_version "0.11.0-svn[get_snapshot [fullpath ChangeLog]]"
+set tkabber_version "0.11.0-svn[get_snapshot [fullpath version]]"
 set toolkit_version "Tcl/Tk [info patchlevel]"
 
 proc rescmd {id res ls} {
