/*
    statusIconClass

    Copyright (c) 2008 by Rustam Chakin <qutim.develop@gmail.com>

 ***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************
*/


#ifndef STATUSICONSCLASS_H_
#define STATUSICONSCLASS_H_

#include <QtGui>
#include "treebuddyitem.h"

class statusIconClass
{
public:
	statusIconClass();
	~statusIconClass();
	
	QString onlinePath;
	QString ffcPath;
	QString awayPath;
	QString naPath;
	QString occupiedPath;
	QString dndPath;
	QString invisiblePath;
	QString offlinePath;
	QString connectingPath;
	QString atHomePath;
	QString atWorkPath;
	QString lunchPath;
	QString evilPath;
	QString depressionPath;
	
	QIcon onlineIcon;
	QIcon ffcIcon;
	QIcon awayIcon;
	QIcon naIcon;
	QIcon occupiedIcon;
	QIcon dndIcon;
	QIcon invisibleIcon;
	QIcon offlineIcon;
	QIcon connectingIcon;
	QIcon atHomeIcon;
	QIcon atWorkIcon;
	QIcon lunchIcon;
	QIcon evilIcon;
	QIcon depressionIcon;
	QList<QString> xstatusList;
	
	void checkForXstatus(treeBuddyItem *);
	
};


#endif /*STATUSICONSCLASS_H_*/
