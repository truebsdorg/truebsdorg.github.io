/*
    statusIconClass

    Copyright (c) 2008 by Rustam Chakin <qutim.develop@gmail.com>

 ***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************
*/


#include "statusiconsclass.h"

statusIconClass::statusIconClass()
{
	onlinePath = ":/icons/icq/online.png";
	ffcPath = ":/icons/icq/ffc.png";
	awayPath = ":/icons/icq/away.png";
	naPath = ":/icons/icq/na.png";
	occupiedPath = ":/icons/icq/occupied.png";
	dndPath = ":/icons/icq/dnd.png";
	invisiblePath = ":/icons/icq/invisible.png";
	offlinePath = ":/icons/icq/offline.png";
	connectingPath = ":/icons/icq/connecting.png";
	atHomePath = ":/icons/icq/athome.png";
	atWorkPath = ":/icons/icq/atwork.png";
	lunchPath = ":/icons/icq/lunch.png";
	evilPath = ":/icons/icq/evil.png";
	depressionPath = ":/icons/icq/depression.png";
	
	onlineIcon = QIcon(onlinePath);
	ffcIcon = QIcon(ffcPath);
	awayIcon = QIcon(awayPath);
	naIcon = QIcon(naPath);
	occupiedIcon = QIcon(occupiedPath);
	dndIcon = QIcon(dndPath);
	invisibleIcon = QIcon(invisiblePath);
	offlineIcon = QIcon(offlinePath);
	connectingIcon = QIcon(connectingPath);
	atHomeIcon = QIcon(atHomePath);
	atWorkIcon = QIcon(atWorkPath);
	lunchIcon = QIcon(lunchPath);
	evilIcon = QIcon(evilPath);
	depressionIcon = QIcon(depressionPath);
	
	xstatusList.append(":/icons/xstatus/icq_xstatus0.png");
	xstatusList.append(":/icons/xstatus/icq_xstatus1.png");
	xstatusList.append(":/icons/xstatus/icq_xstatus2.png");
	xstatusList.append(":/icons/xstatus/icq_xstatus3.png");
	xstatusList.append(":/icons/xstatus/icq_xstatus4.png");
	xstatusList.append(":/icons/xstatus/icq_xstatus5.png");
	xstatusList.append(":/icons/xstatus/icq_xstatus6.png");
	xstatusList.append(":/icons/xstatus/icq_xstatus7.png");
	xstatusList.append(":/icons/xstatus/icq_xstatus8.png");
	xstatusList.append(":/icons/xstatus/icq_xstatus9.png");
	xstatusList.append(":/icons/xstatus/icq_xstatus10.png");
	xstatusList.append(":/icons/xstatus/icq_xstatus11.png");
	xstatusList.append(":/icons/xstatus/icq_xstatus12.png");
	xstatusList.append(":/icons/xstatus/icq_xstatus13.png");
	xstatusList.append(":/icons/xstatus/icq_xstatus14.png");
	xstatusList.append(":/icons/xstatus/icq_xstatus15.png");
	xstatusList.append(":/icons/xstatus/icq_xstatus16.png");
	xstatusList.append(":/icons/xstatus/icq_xstatus17.png");
	xstatusList.append(":/icons/xstatus/icq_xstatus18.png");
	xstatusList.append(":/icons/xstatus/icq_xstatus19.png");
	xstatusList.append(":/icons/xstatus/icq_xstatus20.png");
	xstatusList.append(":/icons/xstatus/icq_xstatus21.png");
	xstatusList.append(":/icons/xstatus/icq_xstatus22.png");
	xstatusList.append(":/icons/xstatus/icq_xstatus23.png");
	xstatusList.append(":/icons/xstatus/icq_xstatus24.png");
	xstatusList.append(":/icons/xstatus/icq_xstatus25.png");
	xstatusList.append(":/icons/xstatus/icq_xstatus26.png");
	xstatusList.append(":/icons/xstatus/icq_xstatus27.png");
	xstatusList.append(":/icons/xstatus/icq_xstatus28.png");
	xstatusList.append(":/icons/xstatus/icq_xstatus29.png");
	xstatusList.append(":/icons/xstatus/icq_xstatus30.png");
	xstatusList.append(":/icons/xstatus/icq_xstatus31.png");
	xstatusList.append(":/icons/xstatus/icq_xstatus32.png");
	xstatusList.append(":/icons/xstatus/icq_xstatus33.png");
	
//	xstatusList.insert(0, ":/icons/xstatus/icq_xstatus0.png");
//	xstatusList.insert(1, ":/icons/xstatus/icq_xstatus1.png");
//	xstatusList.insert(2, ":/icons/xstatus/icq_xstatus2.png");
//	xstatusList.insert(3, ":/icons/xstatus/icq_xstatus3.png");
//	xstatusList.insert(4, ":/icons/xstatus/icq_xstatus4.png");
//	xstatusList.insert(5, ":/icons/xstatus/icq_xstatus5.png");
//	xstatusList.insert(6, ":/icons/xstatus/icq_xstatus6.png");
//	xstatusList.insert(7, ":/icons/xstatus/icq_xstatus7.png");
//	xstatusList.insert(8, ":/icons/xstatus/icq_xstatus8.png");
//	xstatusList.insert(9, ":/icons/xstatus/icq_xstatus9.png");
//	xstatusList.insert(10, ":/icons/xstatus/icq_xstatus10.png");
//	xstatusList.insert(11, ":/icons/xstatus/icq_xstatus11.png");
//	xstatusList.insert(12, ":/icons/xstatus/icq_xstatus12.png");
//	xstatusList.insert(13, ":/icons/xstatus/icq_xstatus13.png");
//	xstatusList.insert(14, ":/icons/xstatus/icq_xstatus14.png");
//	xstatusList.insert(15, ":/icons/xstatus/icq_xstatus15.png");
//	xstatusList.insert(16, ":/icons/xstatus/icq_xstatus16.png");
//	xstatusList.insert(17, ":/icons/xstatus/icq_xstatus17.png");
//	xstatusList.insert(18, ":/icons/xstatus/icq_xstatus18.png");
//	xstatusList.insert(19, ":/icons/xstatus/icq_xstatus19.png");
//	xstatusList.insert(20, ":/icons/xstatus/icq_xstatus20.png");
//	xstatusList.insert(21, ":/icons/xstatus/icq_xstatus21.png");
//	xstatusList.insert(22, ":/icons/xstatus/icq_xstatus22.png");
//	xstatusList.insert(23, ":/icons/xstatus/icq_xstatus23.png");
//	xstatusList.insert(24, ":/icons/xstatus/icq_xstatus24.png");
//	xstatusList.insert(25, ":/icons/xstatus/icq_xstatus25.png");
//	xstatusList.insert(26, ":/icons/xstatus/icq_xstatus26.png");
//	xstatusList.insert(27, ":/icons/xstatus/icq_xstatus27.png");
//	xstatusList.insert(28, ":/icons/xstatus/icq_xstatus28.png");
//	xstatusList.insert(29, ":/icons/xstatus/icq_xstatus29.png");
//	xstatusList.insert(30, ":/icons/xstatus/icq_xstatus30.png");
//	xstatusList.insert(31, ":/icons/xstatus/icq_xstatus31.png");
//	xstatusList.insert(32, ":/icons/xstatus/icq_xstatus32.png");
//	xstatusList.insert(33, ":/icons/xstatus/icq_xstatus33.png");
}

statusIconClass::~statusIconClass()
{
	
}

void statusIconClass::checkForXstatus(treeBuddyItem *buddy)
{
	QList<QByteArray> capList = buddy->capabilitiesList;
	
	if ( capList.contains(QByteArray::fromHex("01d8d7eeac3b492aa58dd3d877e66b92")))
	{
		buddy->xStatusPresent = true;
		buddy->xStatusIcon = xstatusList.at(0);
		buddy->setIcon(1, QIcon(xstatusList.at(0)));
	} else
	if ( capList.contains(QByteArray::fromHex("5a581ea1e580430ca06f612298b7e4c7")))
	{
		buddy->xStatusPresent = true;
		buddy->xStatusIcon = xstatusList.at(1);
		buddy->setIcon(1, QIcon(xstatusList.at(1)));
	}else
	if ( capList.contains(QByteArray::fromHex("83c9b78e77e74378b2c5fb6cfcc35bec")))
	{
		buddy->xStatusPresent = true;
		buddy->xStatusIcon = xstatusList.at(2);
		buddy->setIcon(1, QIcon(xstatusList.at(2)));
	}else
	if ( capList.contains(QByteArray::fromHex("e601e41c33734bd1bc06811d6c323d81")))
	{
		buddy->xStatusPresent = true;
		buddy->xStatusIcon = xstatusList.at(3);
		buddy->setIcon(1, QIcon(xstatusList.at(3)));
	}else
	if ( capList.contains(QByteArray::fromHex("8c50dbae81ed4786acca16cc3213c7b7")))
	{
		buddy->xStatusPresent = true;
		buddy->xStatusIcon = xstatusList.at(4);
		buddy->setIcon(1, QIcon(xstatusList.at(4)));
	}else
	if ( capList.contains(QByteArray::fromHex("3fb0bd36af3b4a609eefcf190f6a5a7f")))
	{
		buddy->xStatusPresent = true;
		buddy->xStatusIcon = xstatusList.at(5);
		buddy->setIcon(1, QIcon(xstatusList.at(5)));
	}else
	if ( capList.contains(QByteArray::fromHex("f8e8d7b282c4414290f810c6ce0a89a6")))
	{
		buddy->xStatusPresent = true;
		buddy->xStatusIcon = xstatusList.at(6);
		buddy->setIcon(1, QIcon(xstatusList.at(6)));
	}else
	if ( capList.contains(QByteArray::fromHex("80537de2a4674a76b3546dfd075f5ec6")))
	{
		buddy->xStatusPresent = true;
		buddy->xStatusIcon = xstatusList.at(7);
		buddy->setIcon(1, QIcon(xstatusList.at(7)));
	}else
	if ( capList.contains(QByteArray::fromHex("f18ab52edc57491d99dc6444502457af")))
	{
		buddy->xStatusPresent = true;
		buddy->xStatusIcon = xstatusList.at(8);
		buddy->setIcon(1, QIcon(xstatusList.at(8)));
	}else
	if ( capList.contains(QByteArray::fromHex("1b78ae31fa0b4d3893d1997eeeafb218")))
	{
		buddy->xStatusPresent = true;
		buddy->xStatusIcon = xstatusList.at(9);
		buddy->setIcon(1, QIcon(xstatusList.at(9)));
	}else
	if ( capList.contains(QByteArray::fromHex("61bee0dd8bdd475d8dee5f4baacf19a7")))
	{
		buddy->xStatusPresent = true;
		buddy->xStatusIcon = xstatusList.at(10);
		buddy->setIcon(1, QIcon(xstatusList.at(10)));
	}else
	if ( capList.contains(QByteArray::fromHex("488e14898aca4a0882aa77ce7a165208")))
	{
		buddy->xStatusPresent = true;
		buddy->xStatusIcon = xstatusList.at(11);
		buddy->setIcon(1, QIcon(xstatusList.at(11)));
	}else
	if ( capList.contains(QByteArray::fromHex("107a9a1812324da4b6cd0879db780f09")))
	{
		buddy->xStatusPresent = true;
		buddy->xStatusIcon = xstatusList.at(12);
		buddy->setIcon(1, QIcon(xstatusList.at(12)));
	}else
	if ( capList.contains(QByteArray::fromHex("6f4930984f7c4affa27634a03bceaea7")))
	{
		buddy->xStatusPresent = true;
		buddy->xStatusIcon = xstatusList.at(13);
		buddy->setIcon(1, QIcon(xstatusList.at(13)));
	}else
	if ( capList.contains(QByteArray::fromHex("1292e5501b644f66b206b29af378e48d")))
	{
		buddy->xStatusPresent = true;
		buddy->xStatusIcon = xstatusList.at(14);
		buddy->setIcon(1, QIcon(xstatusList.at(14)));
	}else
	if ( capList.contains(QByteArray::fromHex("d4a611d08f014ec09223c5b6bec6ccf0")))
	{
		buddy->xStatusPresent = true;
		buddy->xStatusIcon = xstatusList.at(15);
		buddy->setIcon(1, QIcon(xstatusList.at(15)));
	}else
	if ( capList.contains(QByteArray::fromHex("609d52f8a29a49a6b2a02524c5e9d260")))
	{
		buddy->xStatusPresent = true;
		buddy->xStatusIcon = xstatusList.at(16);
		buddy->setIcon(1, QIcon(xstatusList.at(16)));
	}else
	if ( capList.contains(QByteArray::fromHex("63627337a03f49ff80e5f709cde0a4ee")))
	{
		buddy->xStatusPresent = true;
		buddy->xStatusIcon = xstatusList.at(17);
		buddy->setIcon(1, QIcon(xstatusList.at(17)));
	}else
	if ( capList.contains(QByteArray::fromHex("1f7a4071bf3b4e60bc324c5787b04cf1")))
	{
		buddy->xStatusPresent = true;
		buddy->xStatusIcon = xstatusList.at(18);
		buddy->setIcon(1, QIcon(xstatusList.at(18)));
	}else
	if ( capList.contains(QByteArray::fromHex("785e8c4840d34c65886f04cf3f3f43df")))
	{
		buddy->xStatusPresent = true;
		buddy->xStatusIcon = xstatusList.at(19);
		buddy->setIcon(1, QIcon(xstatusList.at(19)));
	}else
	if ( capList.contains(QByteArray::fromHex("a6ed557e6bf744d4a5d4d2e7d95ce81f")))
	{
		buddy->xStatusPresent = true;
		buddy->xStatusIcon = xstatusList.at(20);
		buddy->setIcon(1, QIcon(xstatusList.at(20)));
	}else
	if ( capList.contains(QByteArray::fromHex("12d07e3ef885489e8e97a72a6551e58d")))
	{
		buddy->xStatusPresent = true;
		buddy->xStatusIcon = xstatusList.at(21);
		buddy->setIcon(1, QIcon(xstatusList.at(21)));
	}else
	if ( capList.contains(QByteArray::fromHex("ba74db3e9e24434b87b62f6b8dfee50f")))
	{
		buddy->xStatusPresent = true;
		buddy->xStatusIcon = xstatusList.at(22);
		buddy->setIcon(1, QIcon(xstatusList.at(22)));
	}else
	if ( capList.contains(QByteArray::fromHex("634f6bd8add24aa1aab9115bc26d05a1")))
	{
		buddy->xStatusPresent = true;
		buddy->xStatusIcon = xstatusList.at(23);
		buddy->setIcon(1, QIcon(xstatusList.at(23)));
	}else
	if ( capList.contains(QByteArray::fromHex("2ce0e4e57c6443709c3a7a1ce878a7dc")))
	{
		buddy->xStatusPresent = true;
		buddy->xStatusIcon = xstatusList.at(24);
		buddy->setIcon(1, QIcon(xstatusList.at(24)));
	}else
	if ( capList.contains(QByteArray::fromHex("101117c9a3b040f981ac49e159fbd5d4")))
	{
		buddy->xStatusPresent = true;
		buddy->xStatusIcon = xstatusList.at(25);
		buddy->setIcon(1, QIcon(xstatusList.at(25)));
	}else
	if ( capList.contains(QByteArray::fromHex("160c60bbdd4443f39140050f00e6c009")))
	{
		buddy->xStatusPresent = true;
		buddy->xStatusIcon = xstatusList.at(26);
		buddy->setIcon(1, QIcon(xstatusList.at(26)));
	}else
	if ( capList.contains(QByteArray::fromHex("6443c6af22604517b58cd7df8e290352")))
	{
		buddy->xStatusPresent = true;
		buddy->xStatusIcon = xstatusList.at(27);
		buddy->setIcon(1, QIcon(xstatusList.at(27)));
	}else
	if ( capList.contains(QByteArray::fromHex("16f5b76fa9d240358cc5c084703c98fa")))
	{
		buddy->xStatusPresent = true;
		buddy->xStatusIcon = xstatusList.at(28);
		buddy->setIcon(1, QIcon(xstatusList.at(28)));
	}else
	if ( capList.contains(QByteArray::fromHex("631436ff3f8a40d0a5cb7b66e051b364")))
	{
		buddy->xStatusPresent = true;
		buddy->xStatusIcon = xstatusList.at(29);
		buddy->setIcon(1, QIcon(xstatusList.at(29)));
	}else
	if ( capList.contains(QByteArray::fromHex("b70867f538254327a1ffcf4cc1939797")))
	{
		buddy->xStatusPresent = true;
		buddy->xStatusIcon = xstatusList.at(30);
		buddy->setIcon(1, QIcon(xstatusList.at(30)));
	}else
	if ( capList.contains(QByteArray::fromHex("ddcf0ea971954048a9c6413206d6f280")))
	{
		buddy->xStatusPresent = true;
		buddy->xStatusIcon = xstatusList.at(31);
		buddy->setIcon(1, QIcon(xstatusList.at(31)));
	}else
	if ( capList.contains(QByteArray::fromHex("d4e2b0ba334e4fa598d0117dbf4d3cc8")))
	{
		buddy->xStatusPresent = true;
		buddy->xStatusIcon = xstatusList.at(32);
		buddy->setIcon(1, QIcon(xstatusList.at(32)));
	}else
	if ( capList.contains(QByteArray::fromHex("0072d9084ad143dd91996f026966026f")))
	{
		buddy->xStatusPresent = true;
		buddy->xStatusIcon = xstatusList.at(33);
		buddy->setIcon(1, QIcon(xstatusList.at(33)));
	}
	else
	{
		buddy->xStatusPresent = false;
		buddy->xStatusIcon.clear();
		buddy->waitingForAuth(buddy->authorizeMe);
	}
	
	if ( !buddy->xStatusPresent && !buddy->xStatusMessage.isEmpty())
		{
			QString stat = buddy->xStatusMessage;
			if ( stat == "icqmood23")
			{
				buddy->xStatusPresent = true;
				buddy->xStatusIcon = xstatusList.at(0);
				buddy->setIcon(1, QIcon(xstatusList.at(0)));
			}else
			if ( stat == "icqmood1")
			{
				buddy->xStatusPresent = true;
				buddy->xStatusIcon = xstatusList.at(1);
				buddy->setIcon(1, QIcon(xstatusList.at(1)));
			}else
			if ( stat == "icqmood2")
			{
				buddy->xStatusPresent = true;
				buddy->xStatusIcon = xstatusList.at(2);
				buddy->setIcon(1, QIcon(xstatusList.at(2)));
			}else
			if ( stat == "icqmood3")
			{
				buddy->xStatusPresent = true;
				buddy->xStatusIcon = xstatusList.at(3);
				buddy->setIcon(1, QIcon(xstatusList.at(3)));
			}else
			if ( stat == "icqmood4")
			{
				buddy->xStatusPresent = true;
				buddy->xStatusIcon = xstatusList.at(4);
				buddy->setIcon(1, QIcon(xstatusList.at(4)));
			}else
			if ( stat == "icqmood5")
			{
				buddy->xStatusPresent = true;
				buddy->xStatusIcon = xstatusList.at(5);
				buddy->setIcon(1, QIcon(xstatusList.at(5)));
			}else
			if ( stat == "icqmood6")
			{
				buddy->xStatusPresent = true;
				buddy->xStatusIcon = xstatusList.at(6);
				buddy->setIcon(1, QIcon(xstatusList.at(6)));
			}else
			if ( stat == "icqmood7")
			{
				buddy->xStatusPresent = true;
				buddy->xStatusIcon = xstatusList.at(7);
				buddy->setIcon(1, QIcon(xstatusList.at(7)));
			}else
			if ( stat == "icqmood8")
			{
				buddy->xStatusPresent = true;
				buddy->xStatusIcon = xstatusList.at(8);
				buddy->setIcon(1, QIcon(xstatusList.at(8)));
			}else
			if ( stat == "icqmood9")
			{
				buddy->xStatusPresent = true;
				buddy->xStatusIcon = xstatusList.at(9);
				buddy->setIcon(1, QIcon(xstatusList.at(9)));
			}else
			if ( stat == "icqmood10")
			{
				buddy->xStatusPresent = true;
				buddy->xStatusIcon = xstatusList.at(10);
				buddy->setIcon(1, QIcon(xstatusList.at(10)));
			}else
			if ( stat == "icqmood11")
			{
				buddy->xStatusPresent = true;
				buddy->xStatusIcon = xstatusList.at(11);
				buddy->setIcon(1, QIcon(xstatusList.at(11)));
			}else
			if ( stat == "icqmood12")
			{
				buddy->xStatusPresent = true;
				buddy->xStatusIcon = xstatusList.at(12);
				buddy->setIcon(1, QIcon(xstatusList.at(12)));
			}else
			if ( stat == "icqmood13")
			{
				buddy->xStatusPresent = true;
				buddy->xStatusIcon = xstatusList.at(13);
				buddy->setIcon(1, QIcon(xstatusList.at(13)));
			}else
			if ( stat == "icqmood14")
			{
				buddy->xStatusPresent = true;
				buddy->xStatusIcon = xstatusList.at(14);
				buddy->setIcon(1, QIcon(xstatusList.at(14)));
			}else
			if ( stat == "icqmood15")
			{
				buddy->xStatusPresent = true;
				buddy->xStatusIcon = xstatusList.at(15);
				buddy->setIcon(1, QIcon(xstatusList.at(15)));
			}else
			if ( stat == "icqmood16")
			{
				buddy->xStatusPresent = true;
				buddy->xStatusIcon = xstatusList.at(16);
				buddy->setIcon(1, QIcon(xstatusList.at(16)));
			}else
			if ( stat == "icqmood17")
			{
				buddy->xStatusPresent = true;
				buddy->xStatusIcon = xstatusList.at(18);
				buddy->setIcon(1, QIcon(xstatusList.at(18)));
			}else
			if ( stat == "icqmood18")
			{
				buddy->xStatusPresent = true;
				buddy->xStatusIcon = xstatusList.at(19);
				buddy->setIcon(1, QIcon(xstatusList.at(19)));
			}else
				if ( stat == "icqmood19")
						{
							buddy->xStatusPresent = true;
							buddy->xStatusIcon = xstatusList.at(20);
							buddy->setIcon(1, QIcon(xstatusList.at(20)));
						}else
			if ( stat == "icqmood20")
			{
				buddy->xStatusPresent = true;
				buddy->xStatusIcon = xstatusList.at(21);
				buddy->setIcon(1, QIcon(xstatusList.at(21)));
			}else
			if ( stat == "icqmood21")
			{
				buddy->xStatusPresent = true;
				buddy->xStatusIcon = xstatusList.at(22);
				buddy->setIcon(1, QIcon(xstatusList.at(22)));
			}else
			if ( stat == "icqmood22")
			{
				buddy->xStatusPresent = true;
				buddy->xStatusIcon = xstatusList.at(23);
				buddy->setIcon(1, QIcon(xstatusList.at(23)));
			}
			
		}
}
