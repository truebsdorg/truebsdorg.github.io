/*
    clientIdentify

    Copyright (c) 2008 by Rustam Chakin <qutim.develop@gmail.com>

 ***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************
*/


#ifndef CLIENTIDENTIFY_H_
#define CLIENTIDENTIFY_H_

#include <QtCore>
#include "treebuddyitem.h"

class clientIdentify
{
public:
	clientIdentify();
	~clientIdentify();
	
	void addContactClientId(treeBuddyItem *);
	void removeXstatus(QList<QByteArray> &);
	bool identifyQip2005(const QList<QByteArray> &);
	bool identifyQipInf(const QList<QByteArray> &);
	bool identifyQipSymbian(const QList<QByteArray> &);
	bool identifyQipPDA(const QList<QByteArray> &);
	bool identifyICQ6(const QList<QByteArray> &);
	bool identifyICQ41(const QList<QByteArray> &);
	bool identifyICQ5(const QList<QByteArray> &);
	bool identifyICQ51(const QList<QByteArray> &);
	bool identifyICQ2003b(const QList<QByteArray> &);
	bool identifyICQ2002a(const QList<QByteArray> &);
	bool identifyMiranda804(const QList<QByteArray> &);
	bool identifyMiranda801(const QList<QByteArray> &);
	bool identifyMiranda808(const QList<QByteArray> &);
	bool identifyMiranda8(const QList<QByteArray> &);
	bool identifyMiranda7(const QList<QByteArray> &);
	bool identifyMiranda73(const QList<QByteArray> &);
	bool identifyMiranda700(const QList<QByteArray> &);
	bool identifyMiranda724(const QList<QByteArray> &);
	bool identifyMiranda770(const QList<QByteArray> &);
	bool identifyMiranda702(const QList<QByteArray> &);
	bool identifyMiranda732(const QList<QByteArray> &);
	bool identifyMiranda630(const QList<QByteArray> &);

	bool identifyMiranda67(const QList<QByteArray> &);
	bool identifyMiranda68(const QList<QByteArray> &);
	bool identifySim(const QList<QByteArray> &);
	bool identifySim950(const QList<QByteArray> &);
	bool identifySim942(const QList<QByteArray> &);
	bool identifySmaper143(const QList<QByteArray> &);
	bool identifySmaper151(const QList<QByteArray> &);
	bool identifyPidgin(const QList<QByteArray> &);
	bool identyfiqutim01(const QList<QByteArray> &);
	bool identifyKopete(const QList<QByteArray> &);
	bool identifyKopete501(const QList<QByteArray> &);
	bool identifyKopete5080(const QList<QByteArray> &);
	bool identifyKopete1207(const QList<QByteArray> &);
	bool identifyJimm(const QList<QByteArray> &);
	bool identifyJimm051(const QList<QByteArray> &);
	bool identifyJimm052(const QList<QByteArray> &);
	bool identifyJimm052a(const QList<QByteArray> &);
	bool identifyJimm052b(const QList<QByteArray> &);
	bool identifyJimm060(const QList<QByteArray> &);
	bool identifyGaim2(const QList<QByteArray> &);
	bool identifyRnq1100(const QList<QByteArray> &);
	bool identifyRnq(const QList<QByteArray> &);
	bool identifyMip11(const QList<QByteArray> &);
	bool identifyMip(const QList<QByteArray> &);
	bool identifyInlux(const QList<QByteArray> &);
	bool identifyPigeon(const QList<QByteArray> &);
	bool identifyVmICQ(const QList<QByteArray> &);
	bool identifymChat(const QList<QByteArray> &);
	bool identifydiChat(const QList<QByteArray> &);
};

#endif /*CLIENTIDENTIFY_H_*/
