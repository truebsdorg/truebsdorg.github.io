/*
    clientIdentify

    Copyright (c) 2008 by Rustam Chakin <qutim.develop@gmail.com>

 ***************************************************************************
 *                                                                         *
 *   This program is free software; you can redistribute it and/or modify  *
 *   it under the terms of the GNU General Public License as published by  *
 *   the Free Software Foundation; either version 2 of the License, or     *
 *   (at your option) any later version.                                   *
 *                                                                         *
 ***************************************************************************
*/


#include "clientidentify.h"

clientIdentify::clientIdentify()
{
	
}

clientIdentify::~clientIdentify()
{
	
}

void clientIdentify::addContactClientId(treeBuddyItem *buddy)
{
	QList<QByteArray> tmpList = buddy->capabilitiesList;
	removeXstatus(tmpList);

	if ( identifyQip2005(tmpList) )
	{
		buddy->clientId = "QIP 2005a";
		buddy->setIcon(2, QIcon(":/icons/clients/qip.png"));
		buddy->updateBuddyText();
	} else if ( identifyQipInf(tmpList))
	{
		buddy->clientId = "QIP Infium";
		buddy->setIcon(2, QIcon(":/icons/clients/qipinf.png"));
		buddy->updateBuddyText();
	} 
	else if ( identifyQipSymbian(tmpList))
		{
			buddy->clientId = "QIP PDA Symbian";
			buddy->setIcon(2, QIcon(":/icons/clients/qipsymb.png"));
			buddy->updateBuddyText();
	}else if ( identifyQipPDA(tmpList))
	{
			buddy->clientId = "QIP PDA(Windows)";
			buddy->setIcon(2, QIcon(":/icons/clients/qipsymb.png"));
			buddy->updateBuddyText();
	} else if ( identifyICQ6(tmpList))
	{
		buddy->clientId = "ICQ 6";
		buddy->setIcon(2, QIcon(":/icons/clients/icq6.png"));
		buddy->updateBuddyText();
	}else if ( identifyICQ51(tmpList))
	{
		buddy->clientId = "ICQ 5.1";
		buddy->setIcon(2, QIcon(":/icons/clients/icql5.png"));
		buddy->updateBuddyText();
	}else if ( identifyMiranda804(tmpList))
	{
		buddy->clientId = "Miranda IM 0.8.0.4 alpha Unicode";
		buddy->setIcon(2, QIcon(":/icons/clients/miranda.png"));
		buddy->updateBuddyText();
	}else if ( identifyMiranda7(tmpList))
	{
		buddy->clientId = "Miranda IM version: 0.7.0 alpha build #33 Unicode";
		buddy->setIcon(2, QIcon(":/icons/clients/miranda.png"));
		buddy->updateBuddyText();
	}else if ( identifyMiranda700(tmpList))
	{
		buddy->clientId = "Miranda IM version: 0.7.0.0";
		buddy->setIcon(2, QIcon(":/icons/clients/miranda.png"));
		buddy->updateBuddyText();
	}else if ( identifyMiranda702(tmpList))
	{
		buddy->clientId = "Miranda IM version: 0.7.0.2";
		buddy->setIcon(2, QIcon(":/icons/clients/miranda.png"));
		buddy->updateBuddyText();
	}else if ( identifyMiranda724(tmpList))
	{
		buddy->clientId = "Miranda IM version: 0.7.0.24";
		buddy->setIcon(2, QIcon(":/icons/clients/miranda.png"));
		buddy->updateBuddyText();
	}else if ( identifyMiranda630(tmpList))
	{
		buddy->clientId = "Miranda IM version: 0.6.3";
		buddy->setIcon(2, QIcon(":/icons/clients/miranda.png"));
		buddy->updateBuddyText();
	}else if ( identifyMiranda67(tmpList))
	{
		buddy->clientId = "Miranda IM version: 0.6.7";
		buddy->setIcon(2, QIcon(":/icons/clients/miranda.png"));
		buddy->updateBuddyText();
	}else if ( identifyMiranda68(tmpList))
	{
		buddy->clientId = "Miranda IM version: 0.6.8";
		buddy->setIcon(2, QIcon(":/icons/clients/miranda.png"));
		buddy->updateBuddyText();
	}
	else if ( identifyMiranda73(tmpList))
	{
			buddy->clientId = "Miranda IM version: 0.7.3.0";
			buddy->setIcon(2, QIcon(":/icons/clients/miranda.png"));
			buddy->updateBuddyText();
	}else if ( identifyMiranda770(tmpList))
	{
			buddy->clientId = "Miranda IM version: 0.7.7.0";
			buddy->setIcon(2, QIcon(":/icons/clients/miranda.png"));
			buddy->updateBuddyText();
	}else if ( identifyMiranda732(tmpList))
	{
			buddy->clientId = "Miranda IM version: 0.7.0.32";
			buddy->setIcon(2, QIcon(":/icons/clients/miranda.png"));
			buddy->updateBuddyText();
	}else if ( identifyMiranda801(tmpList))
	{
			buddy->clientId = "Miranda IM version: 0.8.0.1";
			buddy->setIcon(2, QIcon(":/icons/clients/miranda.png"));
			buddy->updateBuddyText();
	}else if ( identifyMiranda8(tmpList))
	{
			buddy->clientId = "Miranda IM version: 0.8.0";
			buddy->setIcon(2, QIcon(":/icons/clients/miranda.png"));
			buddy->updateBuddyText();
	}else if ( identifyMiranda801(tmpList))
	{
			buddy->clientId = "Miranda IM version: 0.8.0.8";
			buddy->setIcon(2, QIcon(":/icons/clients/miranda.png"));
			buddy->updateBuddyText();
	}else if ( identifyPidgin(tmpList))
	{
		buddy->clientId = "Pidgin/GAIM/Adium";
		buddy->setIcon(2, QIcon(":/icons/clients/pidgin.png"));
		buddy->updateBuddyText();
	}else if ( identifySim(tmpList))
	{
		buddy->clientId = "SIM";
		buddy->setIcon(2, QIcon(":/icons/clients/sim.png"));
		buddy->updateBuddyText();
	}else if ( identifySim950(tmpList))
	{
		buddy->clientId = "SIM 0.9.5";
		buddy->setIcon(2, QIcon(":/icons/clients/sim.png"));
		buddy->updateBuddyText();
	}else if ( identifySim942(tmpList))
	{
		buddy->clientId = "SIM 0.9.4.2";
		buddy->setIcon(2, QIcon(":/icons/clients/sim.png"));
		buddy->updateBuddyText();
	}else if ( identifyICQ2003b(tmpList))
	{
		buddy->clientId = "ICQ 2003b";
		buddy->setIcon(2, QIcon(":/icons/clients/icq2003.png"));
		buddy->updateBuddyText();
	}else if ( identifyICQ41(tmpList))
	{
		buddy->clientId = "ICQ 4.1";
		buddy->setIcon(2, QIcon(":/icons/clients/icql4.png"));
		buddy->updateBuddyText();
	}else if ( identifyKopete(tmpList))
	{
		buddy->clientId = "Kopete 0.12";
		buddy->setIcon(2, QIcon(":/icons/clients/kopete.png"));
		buddy->updateBuddyText();
	}else if ( identifyKopete1207(tmpList))
	{
		buddy->clientId = "Kopete 0.12.0.7";
		buddy->setIcon(2, QIcon(":/icons/clients/kopete.png"));
		buddy->updateBuddyText();
	}else if ( identifyKopete501(tmpList))
	{
		buddy->clientId = "Kopete 0.50.1";
		buddy->setIcon(2, QIcon(":/icons/clients/kopete.png"));
		buddy->updateBuddyText();
	}else if ( identifyKopete501(tmpList))
	{
		buddy->clientId = "Kopete 0.50.80";
		buddy->setIcon(2, QIcon(":/icons/clients/kopete.png"));
		buddy->updateBuddyText();
	}else if ( identifyJimm052(tmpList))
	{
		buddy->clientId = "Jimm 0.5.2";
		buddy->setIcon(2, QIcon(":/icons/clients/jimm.png"));
		buddy->updateBuddyText();
	}else if ( identifyJimm052b(tmpList))
	{
		buddy->clientId = "Jimm 0.5.2b";
		buddy->setIcon(2, QIcon(":/icons/clients/jimm.png"));
		buddy->updateBuddyText();
	}else if ( identifyJimm052a(tmpList))
	{
		buddy->clientId = "Jimm 0.5.2a";
		buddy->setIcon(2, QIcon(":/icons/clients/jimm.png"));
		buddy->updateBuddyText();
	}else if ( identifyJimm051(tmpList))
	{
		buddy->clientId = "Jimm 0.5.1";
		buddy->setIcon(2, QIcon(":/icons/clients/jimm.png"));
		buddy->updateBuddyText();
	}else if ( identifyJimm060(tmpList))
	{
		buddy->clientId = "Jimm 0.6.0";
		buddy->setIcon(2, QIcon(":/icons/clients/jimm.png"));
		buddy->updateBuddyText();
	}else if ( identifyJimm(tmpList))
	{
		buddy->clientId = "Jimm";
		buddy->setIcon(2, QIcon(":/icons/clients/jimm.png"));
		buddy->updateBuddyText();
	}else if ( identifySmaper151(tmpList))
	{
		buddy->clientId = "Smaper 1.51";
		buddy->setIcon(2, QIcon(":/icons/clients/smaper.png"));
		buddy->updateBuddyText();
	}else if ( identifySmaper143(tmpList))
	{
		buddy->clientId = "Smaper 1.43";
		buddy->setIcon(2, QIcon(":/icons/clients/smaper.png"));
		buddy->updateBuddyText();
	}
	else if ( identifyGaim2(tmpList))
	{
		buddy->clientId = "Gaim 2.0.0";
		buddy->setIcon(2, QIcon(":/icons/clients/kopete.png"));
		buddy->updateBuddyText();
	}else if ( identifyRnq1100(tmpList))
	{
		buddy->clientId = "R&Q build 1100";
		buddy->setIcon(2, QIcon(":/icons/clients/&RQ.png"));
		buddy->updateBuddyText();
	}else if ( identifyRnq(tmpList))
	{
		buddy->clientId = "&RQ";
		buddy->setIcon(2, QIcon(":/icons/clients/&RQ.png"));
		buddy->updateBuddyText();
	}else if ( identifyInlux(tmpList))
	{
		buddy->clientId = "Inlux";
		buddy->setIcon(2, QIcon());
		buddy->updateBuddyText();
	}else if ( identifyMip11(tmpList))
	{
		buddy->clientId = "mip 1.1";
		buddy->setIcon(2, QIcon(":/icons/clients/mip.png"));
		buddy->updateBuddyText();
	}else if ( identifyMip(tmpList))
	{
		buddy->clientId = "mip";
		buddy->setIcon(2, QIcon(":/icons/clients/mip.png"));
		buddy->updateBuddyText();
	}else if ( identifymChat(tmpList))
	{
		buddy->clientId = "mChat";
		buddy->setIcon(2, QIcon(":/icons/clients/mchat.png"));
		buddy->updateBuddyText();
	}else if ( identifyPigeon(tmpList))
	{
		buddy->clientId = "Pigeon 1.1.0.125";
		buddy->setIcon(2, QIcon(":/icons/clients/smaper.png"));
		buddy->updateBuddyText();
	}else if ( identifyVmICQ(tmpList))
	{
		buddy->clientId = "VmICQ";
		buddy->setIcon(2, QIcon(":/icons/clients/smaper.png"));
		buddy->updateBuddyText();
	}else if ( identifydiChat(tmpList))
	{
		buddy->clientId = "DiChat";
		buddy->setIcon(2, QIcon(":/icons/clients/smaper.png"));
		buddy->updateBuddyText();
	}else  if ( identyfiqutim01(tmpList))
	{
		buddy->clientId = "qutIM 0.1";
		buddy->setIcon(2, QIcon(":/icons/qutim.png"));
		buddy->updateBuddyText();
	}else {
		buddy->clientId = "-";
		buddy->setIcon(2, QIcon(":/icons/clients/unknown.png"));
		buddy->updateBuddyText();
	}
}

bool clientIdentify::identifyQip2005(const QList<QByteArray> &capList)
{

	return capList.contains(QByteArray::fromHex("563fc8090b6f41514950203230303561"));
}

bool clientIdentify::identifyQipInf(const QList<QByteArray> &capList)
{
	

	
	return capList.contains(QByteArray::fromHex("7c737502c3be4f3ea69f015313431e1a"));
									
}

bool clientIdentify::identifyPidgin(const QList<QByteArray> &capList)
{
	

	
	return capList.contains(QByteArray::fromHex("748f2420628711d18222444553540000"));
												 
}
bool clientIdentify::identifyICQ6(const QList<QByteArray> &capList)
{
	
	bool cap1 = false;
	bool cap2 = false;
	bool cap3 = false;
	bool cap4 = false;
	bool cap5 = false;
	bool cap6 = false;
	bool cap7 = false;
	bool cap8 = false;
	bool cap9 = false;

	QByteArray cap1Array = QByteArray::fromHex("0138ca7b769a491588f213fc00979ea8");
	QByteArray cap2Array = QByteArray::fromHex("67361515612d4c078f3dbde6408ea041");
	QByteArray cap3Array = QByteArray::fromHex("1a093c6cd7fd4ec59d51a6474e34f5a0");
	QByteArray cap4Array = QByteArray::fromHex("b2ec8f167c6f451bbd79dc58497888b9");
	QByteArray cap5Array = QByteArray::fromHex("178c2d9bdaa545bb8ddbf3bdbd53a10a");
	QByteArray cap6Array = QByteArray::fromHex("094613494c7f11d18222444553540000");
	QByteArray cap7Array = QByteArray::fromHex("0946134e4c7f11d18222444553540000");
	QByteArray cap8Array = QByteArray::fromHex("094613434c7f11d18222444553540000");
	QByteArray cap9Array = QByteArray::fromHex("563fc8090b6f41bd9f79422609dfa2f3");
	
	for ( int i = 0; i < capList.count(); i++)
	{
		if ( cap1Array == capList.at(i))
			cap1 = true;
		if ( cap2Array == capList.at(i))
			cap2 = true;
		if ( cap3Array == capList.at(i))
			cap3 = true;
		if ( cap4Array == capList.at(i))
			cap4 = true;
		if ( cap5Array == capList.at(i))
			cap5 = true;
		if ( cap6Array == capList.at(i))
			cap6 = true;
		if ( cap7Array == capList.at(i))
			cap7 = true;
		if ( cap8Array == capList.at(i))
			cap8 = true;
		if ( cap9Array == capList.at(i))
			cap9 = true;

	}
	
	return (cap1 & cap2 & cap3 & cap4 & cap5 & cap6 & cap7 & cap8 & cap9);
}

bool clientIdentify::identifyICQ51(const QList<QByteArray> &capList)
{
	
	bool cap1 = false;
	bool cap2 = false;
	bool cap3 = false;
	bool cap4 = false;
	bool cap5 = false;
	bool cap6 = false;
	bool cap7 = false;
	bool cap8 = false;
	bool cap9 = false;
	bool cap10 = false;
	bool cap11 = false;
	bool cap12 = false;

	QByteArray cap1Array = QByteArray::fromHex("094613444c7f11d18222444553540000");
	QByteArray cap2Array = QByteArray::fromHex("094613434c7f11d18222444553540000");
	QByteArray cap3Array = QByteArray::fromHex("0946134c4c7f11d18222444553540000");
	QByteArray cap4Array = QByteArray::fromHex("094613494c7f11d18222444553540000");
	QByteArray cap5Array = QByteArray::fromHex("1a093c6cd7fd4ec59d51a6474e34f5a0");
	QByteArray cap6Array = QByteArray::fromHex("b99708b53a924202b069f1e757bb2e17");
	QByteArray cap7Array = QByteArray::fromHex("67361515612d4c078f3dbde6408ea041");
	QByteArray cap8Array = QByteArray::fromHex("97b12751243c4334ad22d6abf73f1492");
	QByteArray cap9Array = QByteArray::fromHex("178c2d9bdaa545bb8ddbf3bdbd53a10a");
	QByteArray cap10Array = QByteArray::fromHex("e362c1e9121a4b94a6267a74de24270d");
	QByteArray cap11Array = QByteArray::fromHex("563fc8090b6f41bd9f79422609dfa2f3");
	QByteArray cap12Array = QByteArray::fromHex("b2ec8f167c6f451bbd79dc58497888b9");
	
	for ( int i = 0; i < capList.count(); i++)
	{
		if ( cap1Array == capList.at(i))
			cap1 = true;
		if ( cap2Array == capList.at(i))
			cap2 = true;
		if ( cap3Array == capList.at(i))
			cap3 = true;
		if ( cap4Array == capList.at(i))
			cap4 = true;
		if ( cap5Array == capList.at(i))
			cap5 = true;
		if ( cap6Array == capList.at(i))
			cap6 = true;
		if ( cap7Array == capList.at(i))
			cap7 = true;
		if ( cap8Array == capList.at(i))
			cap8 = true;
		if ( cap9Array == capList.at(i))
			cap9 = true;
		if ( cap10Array == capList.at(i))
			cap10 = true;
		if ( cap11Array == capList.at(i))
			cap11 = true;
		if ( cap12Array == capList.at(i))
			cap12 = true;

	}
	
	return (cap1 & cap2 & cap3 & cap4 & cap5 & cap6 & cap7 & cap8 & cap9 & cap10 & cap11 & cap12);
}
bool clientIdentify::identifyICQ5(const QList<QByteArray> &capList)
{
	bool cap1 = false;
	bool cap2 = false;
	bool cap3 = false;
	bool cap4 = false;
	bool cap5 = false;
	bool cap6 = false;
	if ( capList.count() == 6)
	{
		if ( capList.at(0) == QByteArray::fromHex("563fc8090b6f41bd9f79422609dfa2f3"))
			cap1 = true;
		if ( capList.at(1) == QByteArray::fromHex("094613434c7f11d18222444553540000"))
			cap2 = true;
		if ( capList.at(2) == QByteArray::fromHex("785e8c4840d34c65886f04cf3f3f43df"))
			cap3 = true;
		if ( capList.at(3) == QByteArray::fromHex("1a093c6cd7fd4ec59d51a6474e34f5a0"))
			cap4 = true;
		if ( capList.at(4) == QByteArray::fromHex("094613494c7f11d18222444553540000"))
			cap5 = true;
		if ( capList.at(5) == QByteArray::fromHex("094613444c7f11d18222444553540000"))
			cap6 = true;
	}
	return (cap1 & cap2 & cap3 & cap4 & cap5 & cap6);
}
bool clientIdentify::identifyICQ2003b(const QList<QByteArray> &capList)
{
	bool cap1 = false;
	bool cap2 = false;
	bool cap3 = false;
	bool cap4 = false;
	bool cap5 = false;
	if ( capList.count() == 5)
	{
		if ( capList.at(0) == QByteArray::fromHex("094613444c7f11d18222444553540000"))
			cap1 = true;
		if ( capList.at(1) == QByteArray::fromHex("97b12751243c4334ad22d6abf73f1492"))
			cap2 = true;
		if ( capList.at(2) == QByteArray::fromHex("0946134e4c7f11d18222444553540000"))
			cap3 = true;
		if ( capList.at(3) == QByteArray::fromHex("094613494c7f11d18222444553540000"))
			cap4 = true;
		if ( capList.at(4) == QByteArray::fromHex("563fc8090b6f41bd9f79422609dfa2f3"))
			cap5 = true;
	}
	return (cap1 & cap2 & cap3 & cap4 & cap5);
}

bool clientIdentify::identifyICQ2002a(const QList<QByteArray> &capList)
{
	bool cap1 = false;
	bool cap2 = false;
	bool cap3 = false;
	bool cap4 = false;
	if ( capList.count() == 4)
	{
		if ( capList.at(0) == QByteArray::fromHex("094613444c7f11d18222444553540000"))
			cap1 = true;
		if ( capList.at(1) == QByteArray::fromHex("97b12751243c4334ad22d6abf73f1492"))
			cap2 = true;
		if ( capList.at(2) == QByteArray::fromHex("0946134e4c7f11d18222444553540000"))
			cap3 = true;
		if ( capList.at(3) == QByteArray::fromHex("094613494c7f11d18222444553540000"))
			cap4 = true;
	}
	return (cap1 & cap2 & cap3 & cap4);
}

bool clientIdentify::identifyMiranda804(const QList<QByteArray> &capList)
{

	return capList.contains(QByteArray::fromHex("4d6972616e64614d8008000480030a07"));
}

bool clientIdentify::identifyMiranda7(const QList<QByteArray> &capList)
{
	bool cap1 = false;
	bool cap2 = false;
	bool cap3 = false;
	bool cap4 = false;
	bool cap5 = false;
	bool cap6 = false;
	bool cap7 = false;
	bool cap8 = false;

	if ( capList.count() == 8)
	{
		if ( capList.at(0) == QByteArray::fromHex("094613444c7f11d18222444553540000"))
			cap1 = true;
		if ( capList.at(1) == QByteArray::fromHex("0946134c4c7f11d18222444553540000"))
			cap2 = true;
		if ( capList.at(2) == QByteArray::fromHex("094613434c7f11d18222444553540000"))
			cap3 = true;
		if ( capList.at(3) == QByteArray::fromHex("1a093c6cd7fd4ec59d51a6474e34f5a0"))
			cap4 = true;
		if ( capList.at(4) == QByteArray::fromHex("563fc8090b6f41bd9f79422609dfa2f3"))
			cap5 = true;
		if ( capList.at(5) == QByteArray::fromHex("0946134e4c7f11d18222444553540000"))
			cap6 = true;
		if ( capList.at(6) == QByteArray::fromHex("094613494c7f11d18222444553540000"))
			cap7 = true;
		if ( capList.at(7) == QByteArray::fromHex("69637170800700218003086900000000"))
			cap8 = true;

	}
	return (cap1 & cap2 & cap3 & cap4 & cap5 & cap6 & cap7 & cap8);
}


bool clientIdentify::identifySim(const QList<QByteArray> &capList)
{
	bool cap1 = false;
	QByteArray cap1Array = QByteArray::fromHex("53494D20636C69656E74202000090480");
	
	for ( int i = 0; i < capList.count(); i++)
	{
		if ( cap1Array == capList.at(i))
			cap1 = true;
	}
	
	return cap1;
}

bool clientIdentify::identifyICQ41(const QList<QByteArray> &capList)
{
	bool cap1 = false;
	bool cap2 = false;
	bool cap3 = false;
	bool cap4 = false;
	bool cap5 = false;
	bool cap6 = false;
	bool cap7 = false;
	bool cap8 = false;
	
	if ( capList.contains(QByteArray::fromHex("1a093c6cd7fd4ec59d51a6474e34f5a0")))
		cap1 = true;
	if ( capList.contains(QByteArray::fromHex("094613444c7f11d18222444553540000")))
		cap2 = true;
	if ( capList.contains(QByteArray::fromHex("97b12751243c4334ad22d6abf73f1492")))
		cap3 = true;
	if ( capList.contains(QByteArray::fromHex("0946134e4c7f11d18222444553540000")))
		cap4 = true;
	if ( capList.contains(QByteArray::fromHex("178c2d9bdaa545bb8ddbf3bdbd53a10a")))
		cap5 = true;
	if ( capList.contains(QByteArray::fromHex("0946134c4c7f11d18222444553540000")))
		cap6 = true;
	if ( capList.contains(QByteArray::fromHex("094613494c7f11d18222444553540000")))
		cap7 = true;
	if ( capList.contains(QByteArray::fromHex("563fc8090b6f41bd9f79422609dfa2f3")))
		cap8 = true;
	return (cap1 & cap2 & cap3 & cap4 & cap5 & cap6 & cap7 & cap8);
}

bool clientIdentify::identyfiqutim01(const QList<QByteArray> &capList)
{
	return capList.contains(QByteArray::fromHex("717574696d302e310000000000000000"));

}

bool clientIdentify::identifyMiranda702(const QList<QByteArray> &capList)
{
	return capList.contains(QByteArray::fromHex("4d6972616e64614d8007000200030904"));

}

bool clientIdentify::identifyKopete(const QList<QByteArray> &capList)
{
	return capList.contains(QByteArray::fromHex("4b6f70657465204943512020000c0001"));
												 
}

bool clientIdentify::identifyKopete501(const QList<QByteArray> &capList)
{
	return capList.contains(QByteArray::fromHex("4b6f7065746520494351202000320001"));

}

bool clientIdentify::identifyKopete5080(const QList<QByteArray> &capList)
{
	return capList.contains(QByteArray::fromHex("4b6f7065746520494351202000320050"));

}

void clientIdentify::removeXstatus(QList<QByteArray> &list)
{
	list.removeAll(QByteArray::fromHex("01d8d7eeac3b492aa58dd3d877e66b92"));
	list.removeAll(QByteArray::fromHex("5a581ea1e580430ca06f612298b7e4c7"));
	list.removeAll(QByteArray::fromHex("83c9b78e77e74378b2c5fb6cfcc35bec"));
	list.removeAll(QByteArray::fromHex("e601e41c33734bd1bc06811d6c323d81"));
	list.removeAll(QByteArray::fromHex("8c50dbae81ed4786acca16cc3213c7b7"));
	list.removeAll(QByteArray::fromHex("3fb0bd36af3b4a609eefcf190f6a5a7f"));
	list.removeAll(QByteArray::fromHex("f8e8d7b282c4414290f810c6ce0a89a6"));
	list.removeAll(QByteArray::fromHex("80537de2a4674a76b3546dfd075f5ec6"));
	list.removeAll(QByteArray::fromHex("f18ab52edc57491d99dc6444502457af"));
	list.removeAll(QByteArray::fromHex("1b78ae31fa0b4d3893d1997eeeafb218"));
	list.removeAll(QByteArray::fromHex("61bee0dd8bdd475d8dee5f4baacf19a7"));
	list.removeAll(QByteArray::fromHex("488e14898aca4a0882aa77ce7a165208"));
	list.removeAll(QByteArray::fromHex("107a9a1812324da4b6cd0879db780f09"));
	list.removeAll(QByteArray::fromHex("6f4930984f7c4affa27634a03bceaea7"));
	list.removeAll(QByteArray::fromHex("1292e5501b644f66b206b29af378e48d"));
	list.removeAll(QByteArray::fromHex("d4a611d08f014ec09223c5b6bec6ccf0"));
	list.removeAll(QByteArray::fromHex("609d52f8a29a49a6b2a02524c5e9d260"));
	list.removeAll(QByteArray::fromHex("63627337a03f49ff80e5f709cde0a4ee"));
	list.removeAll(QByteArray::fromHex("1f7a4071bf3b4e60bc324c5787b04cf1"));
	list.removeAll(QByteArray::fromHex("785e8c4840d34c65886f04cf3f3f43df"));
	list.removeAll(QByteArray::fromHex("a6ed557e6bf744d4a5d4d2e7d95ce81f"));
	list.removeAll(QByteArray::fromHex("12d07e3ef885489e8e97a72a6551e58d"));
	list.removeAll(QByteArray::fromHex("ba74db3e9e24434b87b62f6b8dfee50f"));
	list.removeAll(QByteArray::fromHex("634f6bd8add24aa1aab9115bc26d05a1"));
	list.removeAll(QByteArray::fromHex("2ce0e4e57c6443709c3a7a1ce878a7dc"));
	list.removeAll(QByteArray::fromHex("101117c9a3b040f981ac49e159fbd5d4"));
	list.removeAll(QByteArray::fromHex("160c60bbdd4443f39140050f00e6c009"));
	list.removeAll(QByteArray::fromHex("6443c6af22604517b58cd7df8e290352"));
	list.removeAll(QByteArray::fromHex("16f5b76fa9d240358cc5c084703c98fa"));
	list.removeAll(QByteArray::fromHex("631436ff3f8a40d0a5cb7b66e051b364"));
	list.removeAll(QByteArray::fromHex("b70867f538254327a1ffcf4cc1939797"));
	list.removeAll(QByteArray::fromHex("ddcf0ea971954048a9c6413206d6f280"));
	list.removeAll(QByteArray::fromHex("d4e2b0ba334e4fa598d0117dbf4d3cc8"));
	list.removeAll(QByteArray::fromHex("0072d9084ad143dd91996f026966026f"));
}

bool clientIdentify::identifyJimm052(const QList<QByteArray> &capList)
{
	bool cap1 = false;
	bool cap2 = false;
	bool cap3 = false;
	if ( capList.count() == 3)
	{
		if ( capList.at(0) == QByteArray::fromHex("0946134e4c7f11d18222444553540000"))
			cap1 = true;
		if ( capList.at(1) == QByteArray::fromHex("094613444c7f11d18222444553540000"))
			cap2 = true;
		if ( capList.at(2) == QByteArray::fromHex("094613494c7f11d18222444553540000"))
			cap3 = true;
	}
	return (cap1 & cap2 & cap3);
}

bool clientIdentify::identifyGaim2(const QList<QByteArray> &capList)
{
	bool cap1 = false;
	bool cap2 = false;
	bool cap3 = false;
	bool cap4 = false;
	if ( capList.count() == 4)
	{
		if ( capList.at(0) == QByteArray::fromHex("0946134e4c7f11d18222444553540000"))
			cap1 = true;
		if ( capList.at(1) == QByteArray::fromHex("094613464c7f11d18222444553540000"))
			cap2 = true;
		if ( capList.at(2) == QByteArray::fromHex("094613454c7f11d18222444553540000"))
			cap3 = true;
		if ( capList.at(3) == QByteArray::fromHex("094613434c7f11d18222444553540000"))
			cap4 = true;
	}
	return (cap1 & cap2 & cap3 & cap4);
}
bool clientIdentify::identifyRnq1100(const QList<QByteArray> &capList)
{
//	bool cap1 = false;
//	bool cap2 = false;
//	bool cap3 = false;
//	bool cap4 = false;
//	bool cap5 = false;
//	bool cap6 = false;
//	bool cap7 = false;
//	if ( capList.count() == 7)
//	{
//		if ( capList.at(0) == QByteArray::fromHex("b2ec8f167c6f451bbd79dc58497888b9"))
//			cap1 = true;
//		if ( capList.at(1) == QByteArray::fromHex("83c9b78e77e74378b2c5fb6cfcc35bec"))
//			cap2 = true;
//		if ( capList.at(2) == QByteArray::fromHex("0946134c4c7f11d18222444553540000"))
//			cap3 = true;
//		if ( capList.at(3) == QByteArray::fromHex("0946134e4c7f11d18222444553540000"))
//			cap4 = true;
//		if ( capList.at(4) == QByteArray::fromHex("563fc8090b6f41bd9f79422609dfa2f3"))
//			cap5 = true;
//		if ( capList.at(5) == QByteArray::fromHex("094613444c7f11d18222444553540000"))
//			cap6 = true;
//		if ( capList.at(6) == QByteArray::fromHex("094613494c7f11d18222444553540000"))
//			cap7 = true;
//	}
//	return (cap1 & cap2 & cap3 & cap4 & cap5 & cap6 & cap7);
	return capList.contains(QByteArray::fromHex("d6687f4f3dc34bdb8a8c4c1a572763cd"));

}

bool clientIdentify::identifyRnq(const QList<QByteArray> &capList)
{
	return capList.contains(QByteArray::fromHex("265251696e7369646508080900000000"));

}

bool clientIdentify::identifyJimm052b(const QList<QByteArray> &capList)
{
	return capList.contains(QByteArray::fromHex("4a696d6d20302e352e32620000000000"));

}

bool clientIdentify::identifyJimm051(const QList<QByteArray> &capList)
{
	return capList.contains(QByteArray::fromHex("4a696d6d20302e352e31000000000000"));

}

bool clientIdentify::identifyJimm(const QList<QByteArray> &capList)
{
	return (capList.contains(QByteArray::fromHex("4a696d6d20466f72206d617374657273")) || capList.contains(QByteArray::fromHex("4a696d6d20434f524520506167657200")));

}

bool clientIdentify::identifyJimm052a(const QList<QByteArray> &capList)
{
	return capList.contains(QByteArray::fromHex("4a696d6d20302e352e32610000000000"));

}

bool clientIdentify::identifyJimm060(const QList<QByteArray> &capList)
{
	return capList.contains(QByteArray::fromHex("4a696d6d20302e362e30620000000000"));

}

bool clientIdentify::identifyMip11(const QList<QByteArray> &capList)
{
	bool cap1 = false;
	bool cap2 = false;
	bool cap3 = false;
	bool cap4 = false;
	bool cap5 = false;
	if ( capList.count() == 5)
	{
		if ( capList.at(0) == QByteArray::fromHex("0946134e4c7f11d18222444553540000"))
			cap1 = true;
		if ( capList.at(1) == QByteArray::fromHex("094613464c7f11d18222444553540000"))
			cap2 = true;
		if ( capList.at(2) == QByteArray::fromHex("094613454c7f11d18222444553540000"))
			cap3 = true;
		if ( capList.at(3) == QByteArray::fromHex("094613434c7f11d18222444553540000"))
			cap4 = true;
		if ( capList.at(4) == QByteArray::fromHex("094613434c7f11d18222444553540000"))
			cap5 = true;
	}
	return (cap1 & cap2 & cap3 & cap4 & cap5);
}

bool clientIdentify::identifyMiranda700(const QList<QByteArray> &capList)
{
	return (capList.contains(QByteArray::fromHex("4d6972616e64614d0007000080030a03")) || capList.contains(QByteArray::fromHex("4d6972616e64614d0007000000030905")) ||
			capList.contains(QByteArray::fromHex("696371708007001f800308695afec0de")) || capList.contains(QByteArray::fromHex("4d495020000000000000000000060000")) ||
			capList.contains(QByteArray::fromHex("4d6972616e64614d0007000080030a05")) );

}

bool clientIdentify::identifyMiranda630(const QList<QByteArray> &capList)
{
	return capList.contains(QByteArray::fromHex("4d6972616e64614d0006030000030706"));

}
bool clientIdentify::identifySmaper143(const QList<QByteArray> &capList)
{
	return capList.contains(QByteArray::fromHex("536d617065722076312e343373000000"));

}

bool clientIdentify::identifySmaper151(const QList<QByteArray> &capList)
{
	return capList.contains(QByteArray::fromHex("536d617065722076312e353173000000"));

}

bool clientIdentify::identifySim950(const QList<QByteArray> &capList)
{
	return capList.contains(QByteArray::fromHex("53494d20636c69656e74202000090500"));

}

bool clientIdentify::identifySim942(const QList<QByteArray> &capList)
{
	return capList.contains(QByteArray::fromHex("53494d20636c69656e74202000090402"));

}

bool clientIdentify::identifyKopete1207(const QList<QByteArray> &capList)
{
	return capList.contains(QByteArray::fromHex("4b6f70657465204943512020000c0007"));

}

bool clientIdentify::identifyMiranda67(const QList<QByteArray> &capList)
{
	return capList.contains(QByteArray::fromHex("4d6972616e64614d0006070000030706"));

}

bool clientIdentify::identifyMiranda68(const QList<QByteArray> &capList)
{
	return capList.contains(QByteArray::fromHex("4d6972616e64614d0006080000030905"));

}
bool clientIdentify::identifyMiranda73(const QList<QByteArray> &capList)
{
	return capList.contains(QByteArray::fromHex("69637170000703008003086900000000"));

}
bool clientIdentify::identifyMiranda770(const QList<QByteArray> &capList)
{
	return capList.contains(QByteArray::fromHex("4d6972616e64614d0007070000030a0d"));

}
bool clientIdentify::identifyMiranda732(const QList<QByteArray> &capList)
{
	return capList.contains(QByteArray::fromHex("4d6972616e64614d8007002080030a04"));

}
bool clientIdentify::identifyMiranda724(const QList<QByteArray> &capList)
{
	return capList.contains(QByteArray::fromHex("4d6972616e64614d8007001880030a02"));

}

bool clientIdentify::identifyMiranda8(const QList<QByteArray> &capList)
{
	return capList.contains(QByteArray::fromHex("4d6972616e64614d0008000000030706"));

}

bool clientIdentify::identifyMiranda801(const QList<QByteArray> &capList)
{
	return capList.contains(QByteArray::fromHex("69637170800800018003086900000000"));

}
bool clientIdentify::identifyMiranda808(const QList<QByteArray> &capList)
{
	return capList.contains(QByteArray::fromHex("69637170800800088003086900000000"));

}

bool clientIdentify::identifyInlux(const QList<QByteArray> &capList)
{
	return capList.contains(QByteArray::fromHex("a7e40a96b3a0479ab845c9e467c56b1f"));

}
bool clientIdentify::identifyPigeon(const QList<QByteArray> &capList)
{
	return capList.contains(QByteArray::fromHex("504947454f4e21000000000000000000"));

}

bool clientIdentify::identifyQipSymbian(const QList<QByteArray> &capList)
{
	return capList.contains(QByteArray::fromHex("51add1907204473da1a149f4a397a41f"));

}

bool clientIdentify::identifyQipPDA(const QList<QByteArray> &capList)
{
	return capList.contains(QByteArray::fromHex("563fc8090b6f41514950202020202021"));
												 
}

bool clientIdentify::identifyVmICQ(const QList<QByteArray> &capList)
{
	return (capList.contains(QByteArray::fromHex("566d49435120302e312e376200000000")) || capList.contains(QByteArray::fromHex("566d49435120302e322e326100000000")));

}

bool clientIdentify::identifymChat(const QList<QByteArray> &capList)
{
	return capList.contains(QByteArray::fromHex("6d436861742069637120322e332e306d"));

}

bool clientIdentify::identifydiChat(const QList<QByteArray> &capList)
{
	return capList.contains(QByteArray::fromHex("445b695d4368617420762e302e340000"));

}

bool clientIdentify::identifyMip(const QList<QByteArray> &capList)
{
	return capList.contains(QByteArray::fromHex("4d4950200076312e3100000000000000"));

}
