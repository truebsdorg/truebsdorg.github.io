#ifndef KEYSMANAGER_H
#define KEYSMANAGER_H

#include <QtGui/QDialog>
#include <QSettings>
#include "ui_keysmanager.h"

class KeysManager : public QDialog
{
	Q_OBJECT

public:
	KeysManager(QWidget *parent = 0);
	~KeysManager();

	Ui::KeysManagerClass ui;

private:
	void Save();
	void Load();
	bool ValidateInputData();

private slots:
	void on_key2Edit_textChanged(const QString &);
	void on_key1Edit_textChanged(const QString &);
	void on_hideCheckBox_stateChanged(int);
	void on_pushButton_2_clicked();
};

#endif // KEYSMANAGER_H
