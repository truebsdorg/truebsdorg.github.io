#ifndef CRYPTOSETTINGS_H
#define CRYPTOSETTINGS_H

#include <QWidget>
#include "ui_cryptosettings.h"
#include <QSettings>

class cryptoSettings : public QWidget
{
	Q_OBJECT

public:
	cryptoSettings(QWidget *parent = 0);
	~cryptoSettings();
	void loadSettings(const QString &);
    void saveSettings(const QString &);

private:
	Ui::cryptoSettingsClass ui;
};

#endif // CRYPTOSETTINGS_H
