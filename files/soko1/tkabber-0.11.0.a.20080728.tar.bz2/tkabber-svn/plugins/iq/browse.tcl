# $Id: browse.tcl 1203 2007-08-30 16:56:14Z sergei $

proc iq_browse_reply {connid from lang child} {
    set restags {}
    foreach ns [lsort $::iq::supported_ns] {
	lappend restags [jlib::wrapper:createtag ns \
			     -chdata $ns]
    }
    
    set res [jlib::wrapper:createtag query \
		 -vars {xmlns    jabber:iq:browse \
			category user \
			type     client \
			name     Tkabber} \
		 -subtags $restags]
    
    return [list result $res]
}

iq::register_handler get {} jabber:iq:browse \
    [namespace current]::iq_browse_reply

