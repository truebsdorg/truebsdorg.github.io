# $Id: last.tcl 859 2007-01-05 12:24:11Z sergei $

custom::defvar options(reply_iq_last) 1 \
    [::msgcat::mc "Reply to idle time (jabber:iq:last) requests."] \
    -group IQ -type boolean

proc iq_last {connid from lang child} {
    global idle_command
    global userstatus statusdesc textstatus
    variable options

    jlib::wrapper:splitxml $child tag vars isempty chdata children

    if {$options(reply_iq_last) && [info exists idle_command]} {
	set seconds [expr {[eval $idle_command]/1000}]
	set status $statusdesc($userstatus)
	if {[cequal $textstatus ""]} {
	    set status "$statusdesc($userstatus) ($userstatus)"
	} else {
	    set status "$textstatus ($userstatus)"
	}
	return [list result [jlib::wrapper:createtag query \
		    -vars [list xmlns jabber:iq:last seconds $seconds] \
		    -chdata $status]]
    } else {
	return [list error cancel service-unavailable]
    }
}

iq::register_handler get query jabber:iq:last [namespace current]::iq_last

