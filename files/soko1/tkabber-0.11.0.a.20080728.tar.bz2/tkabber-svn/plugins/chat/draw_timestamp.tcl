# $Id: draw_timestamp.tcl 1442 2008-05-21 11:36:30Z sergei $

custom::defvar options(timestamp_format) {[%R]} \
    [::msgcat::mc "Format of timestamp in chat message.\
		   Refer to Tcl documentation of 'clock' command for\
		   description of format.\n\nExamples:\n \
		   \[%R\] - \[20:37\]\n  \[%T\] - \[20:37:12\]\n \
		   \[%a %b %d %H:%M:%S %Z %Y\] -\
		   \[Thu Jan 01 03:00:00 MSK 1970\]"] \
    -type string -group Chat
custom::defvar options(delayed_timestamp_format) {[%m/%d %R]} \
    [::msgcat::mc "Format of timestamp in delayed chat messages delayed\
for more than 24 hours."] \
    -type string -group Chat

proc draw_timestamp {chatid from type body x} {
    variable options

    set chatw [chat::chat_win $chatid]

    set seconds [jlib::x_delay $x]
    set seconds1 [expr {[clock seconds] - 24*60*60 + 60}]
    if {$seconds <= $seconds1} {
	set format $options(delayed_timestamp_format)
    } else {
	set format $options(timestamp_format)
    }

    $chatw insert end [clock format $seconds -format $format]
}
hook::add draw_message_hook [namespace current]::draw_timestamp 15
