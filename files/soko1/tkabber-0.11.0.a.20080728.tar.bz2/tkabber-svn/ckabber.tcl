#!/bin/sh
# the next line restarts using the correct interpreter \
exec cwsh "$0" -name ckabber "$@"

# $Id: ckabber.tcl

set interface ck
namespace eval ifaceck {}

lappend auto_path [file dirname [info script]]

package require msgcat
if {[info exists ::env(LC_MESSAGES)]} {
    ::msgcat::mclocale $::env(LC_MESSAGES)
}

set configdir [file join ~ .tkabber]
catch {set configdir [file normalize $configdir]}

set tkabber_version 0.9.7-alpha-20031223
set toolkit_version "Tcl/Ck [info patchlevel]"


if {$tcl_platform(platform) == "unix"} {
    set debug_lvls {jlib warning}
} else {
    set debug_lvls {}
}

proc debugmsg {level msg} {
    global debug_lvls

    if {[lsearch -exact $debug_lvls $level] >= 0} {
	# puts "$level: $msg"
    }
}

proc rescmd {id res ls} {
    puts "RESULT: $id $res $ls"
}

set rootdir [file dirname [info script]]
proc fullpath {args} {
    global rootdir
    return [eval file join $rootdir $args]
}

proc pixmap {args} {
    # TODO
}

proc load_source {args} {
    set fullpath [eval fullpath $args]

    debugmsg tkabber "Loading $fullpath"
    uplevel #0 source $fullpath
}

load_source ifaceck widgets.tcl

proc quit {{status 0}} {
    hook::run quit_hook

    destroy .
    exit $status
}

namespace eval ssj {}
load_source hooks.tcl

load_source default.tcl

hook::add postload_hook postload
hook::add finload_hook finload

if {[file exists [file join $::configdir config.tcl]]} {
    source [file join $::configdir config.tcl]
}

if {(![info exists load_default_xrdb] || $load_default_xrdb)} {
    option readfile [fullpath ifaceck default.xrdb] widgetDefault
}

::msgcat::mcload [file join $rootdir msgs]
foreach pr [::msgcat::mcpreferences] {
    set f [file join $rootdir msgs "$pr.rc"]
    if {[file exists $f]} {
	option read $f
	break
    }
}
unset pr f

if {[catch { package require Tclx }]} {
    load_source Tclx.tcl
}

package require jabberlib 0.8.4
load_source xmppmime.tcl

foreach {opt val} $argv {
    switch -- $opt {
	-mime {set mime_file $val}
	-user {set loginconf(user) $val}
	-password {set loginconf(password) $val}
	-resource {set loginconf(resource) $val}
	-port {set loginconf(port) $val}
	-autologin {set autologin $val}
	-chat {xmppmime::send_event [list chat $val]}
	-message {xmppmime::send_event [list message $val]}
	-conference {xmppmime::send_event [list groupchat $val]}
    }
}

if {[info exists mime_file]} {
    xmppmime::load $mime_file
}
if {[xmppmime::is_done]} exit

#if {![info exists show_splash_window] || $show_splash_window} {
#    load_source splash.tcl
#}


proc ::LOG {text} {
    debugmsg jlib $text
}

proc ::HTTP_LOG {text} {
    debugmsg http $text
}

load_source custom.tcl
load_source utils.tcl
load_source plugins.tcl
#load_source balloon.tcl
load_source presence.tcl
#load_source iq.tcl
load_source roster.tcl
#load_source itemedit.tcl
#load_source sound.tcl
#load_source messages.tcl
load_source chats.tcl
#load_source joingrdialog.tcl
#load_source muc.tcl
#load_source emoticons.tcl
load_source login.tcl
#load_source browser.tcl
#load_source disco.tcl
#load_source userinfo.tcl
#load_source datagathering.tcl
#load_source negotiate.tcl
#load_source mclistbox mclistbox.tcl
#load_source search.tcl
#load_source register.tcl
#load_source filetransfer.tcl
#load_source filters.tcl
#load_source privacy.tcl
load_source gpgme.tcl
#load_source bwidget_workarounds.tcl
#load_source aniemoteicons aniemoteicons.tcl

#plugins::load [file join plugins general]
#plugins::load [file join plugins $tcl_platform(platform)]
#plugins::load_dir [file join $::configdir plugins]

load_source ifaceck iface.tcl

hook::run postload_hook

load_source iface.tcl

hook::run finload_hook

